package com.nkl.admin.action;

import java.util.Date;
import java.util.List;

import com.nkl.admin.domain.Classes;
import com.nkl.admin.domain.Course;
import com.nkl.admin.domain.Major;
import com.nkl.admin.domain.Score;
import com.nkl.admin.domain.User;
import com.nkl.admin.manager.AdminManager;
import com.nkl.common.action.BaseAction;
import com.nkl.common.util.DateUtil;
import com.nkl.common.util.Param;

public class AdminAction  extends BaseAction {

	private static final long serialVersionUID = 1L;
	AdminManager adminManager = new AdminManager();
	
	//抓取页面参数
	User paramsUser;
	Classes paramsClasses;
	Course paramsCourse;
	Major paramsMajor;
	Score paramsScore;
	
	String tip;
	
	/**
	 * @Title: saveAdmin
	 * @Description: 保存修改个人信息
	 * @return String
	 */
	public String saveAdmin(){
		try {
			//验证学生会话是否失效
			if (!validateAdmin()) {
				return "loginTip";
			}
			 //保存修改个人信息
			adminManager.updateUser(paramsUser);
			//更新session
			User admin = new User();
			admin.setUser_id(paramsUser.getUser_id());
			admin = adminManager.queryUser(admin);
			Param.setSession("admin", admin);
			
			setSuccessTip("编辑成功", "modifyInfo.jsp");
			
		} catch (Exception e) {
			setErrorTip("编辑异常", "modifyInfo.jsp");
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: saveAdminPass
	 * @Description: 保存修改个人密码
	 * @return String
	 */
	public String saveAdminPass(){
		try {
			//验证学生会话是否失效
			if (!validateAdmin()) {
				return "loginTip";
			}
			 //保存修改个人密码
			//paramsUser.setUser_pass(Md5.makeMd5(paramsUser.getUser_pass()));
			adminManager.updateUser(paramsUser);
			//更新session
			User admin = (User)Param.getSession("admin");
			if (admin!=null) {
				admin.setUser_pass(paramsUser.getUser_pass());
				Param.setSession("admin", admin);
			}
			
			setSuccessTip("修改成功", "modifyPwd.jsp");
		} catch (Exception e) {
			setErrorTip("修改异常", "modifyPwd.jsp");
		}
		
		return "infoTip";
	}
	
	
	/**
	 * @Title: listUsers
	 * @Description: 查询学生
	 * @return String
	 */
	public String listUsers(){
		try {
			if (paramsUser==null) {
				paramsUser = new User();
			}
			//查看学生信息
			paramsUser.setUser_type(1);
			
			//设置分页信息
			setPagination(paramsUser);
			//总的条数
			int[] sum={0};
			//查询学生列表
			List<User> users = adminManager.listUsers(paramsUser,sum); 
			
			Param.setAttribute("users", users);
			setTotalCount(sum[0]);
			
		} catch (Exception e) {
			setErrorTip("查询学生异常", "main.jsp");
			return "infoTip";
		}
		
		return "userShow";
	}
	
	/**
	 * @Title: queryStudent
	 * @Description: 查询学生
	 * @return String
	 */
	public String queryStudent(){
		try {
			if (paramsUser==null) {
				paramsUser = new User();
			}
			paramsUser.setUser_type(1);
			paramsUser.setStart(-1);
			//查询学生列表
			List<User> users = adminManager.listUsers(paramsUser,null); 
			
			setResult("users", users);
			
		} catch (Exception e) {
			setErrorReason("查询学生信息失败，服务器异常！",e);
			return "error";
		}
		
		return "success";
	}
	
	/**
	 * @Title: addUserShow
	 * @Description: 显示添加学生页面
	 * @return String
	 */
	public String addUserShow(){
		//查询班级、专业字典
		Classes classes = new Classes();
		classes.setStart(-1);
		List<Classes> classess = adminManager.listClassess(classes, null);
		Param.setAttribute("classess", classess);
		
		Major major = new Major();
		major.setStart(-1);
		List<Major> majors = adminManager.listMajors(major, null);
		Param.setAttribute("majors", majors);
		
		return "userEdit";
	}
	
	/**
	 * @Title: addUser
	 * @Description: 添加学生
	 * @return String
	 */
	public String addUser(){
		try {
			//检查学生是否存在
			User user = new User();
			user.setUser_name(paramsUser.getUser_name());
			user = adminManager.queryUser(user);
			if (user!=null) {
				tip="失败，该学号已经存在！";
				Param.setAttribute("user", paramsUser);
				
				//查询班级、专业字典
				Classes classes = new Classes();
				classes.setStart(-1);
				List<Classes> classess = adminManager.listClassess(classes, null);
				Param.setAttribute("classess", classess);
				
				Major major = new Major();
				major.setStart(-1);
				List<Major> majors = adminManager.listMajors(major, null);
				Param.setAttribute("majors", majors);
				
				return "userEdit";
			}
			
			 //添加学生
			paramsUser.setUser_type(1);
			paramsUser.setReg_date(DateUtil.dateToDateString(new Date(), "yyyy-MM-dd HH:mm:ss"));
			adminManager.addUser(paramsUser);
			
			setSuccessTip("添加成功", "Admin_listUsers.action");
		} catch (Exception e) {
			setErrorTip("添加学生异常", "Admin_listUsers.action");
		}
		
		return "infoTip";
	}
	
	 
	/**
	 * @Title: editUser
	 * @Description: 编辑学生
	 * @return String
	 */
	public String editUser(){
		try {
			 //得到学生
			User user = adminManager.queryUser(paramsUser);
			Param.setAttribute("user", user);
			
			//查询班级、专业字典
			Classes classes = new Classes();
			classes.setStart(-1);
			List<Classes> classess = adminManager.listClassess(classes, null);
			Param.setAttribute("classess", classess);
			
			Major major = new Major();
			major.setStart(-1);
			List<Major> majors = adminManager.listMajors(major, null);
			Param.setAttribute("majors", majors);
			
		} catch (Exception e) {
			setErrorTip("查询学生异常", "Admin_listUsers.action");
			return "infoTip";
		}
		
		return "userEdit";
	}
	
	/**
	 * @Title: saveUser
	 * @Description: 保存编辑学生
	 * @return String
	 */
	public String saveUser(){
		try {
			 //保存编辑学生
			adminManager.updateUser(paramsUser);
			
			setSuccessTip("编辑成功", "Admin_listUsers.action");
		} catch (Exception e) {
			tip="编辑失败";
			Param.setAttribute("user", paramsUser);
			
			//查询班级、专业字典
			Classes classes = new Classes();
			classes.setStart(-1);
			List<Classes> classess = adminManager.listClassess(classes, null);
			Param.setAttribute("classess", classess);
			
			Major major = new Major();
			major.setStart(-1);
			List<Major> majors = adminManager.listMajors(major, null);
			Param.setAttribute("majors", majors);
			
			return "userEdit";
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: delUsers
	 * @Description: 删除学生
	 * @return String
	 */
	public String delUsers(){
		try {
			 //删除学生
			adminManager.delUsers(paramsUser);
			
			setSuccessTip("删除学生成功", "Admin_listUsers.action");
		} catch (Exception e) {
			setErrorTip("删除学生异常", "Admin_listUsers.action");
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: listMajors
	 * @Description: 查询专业
	 * @return String
	 */
	public String listMajors(){
		try {
			if (paramsMajor==null) {
				paramsMajor = new Major();
			}
			//设置分页信息
			setPagination(paramsMajor);
			//总的条数
			int[] sum={0};
			//查询专业列表
			List<Major> majors = adminManager.listMajors(paramsMajor,sum); 
			
			Param.setAttribute("majors", majors);
			setTotalCount(sum[0]);
			
		} catch (Exception e) {
			setErrorTip("查询专业异常", "main.jsp");
			return "infoTip";
		}
		
		return "majorShow";
	}
	
	/**
	 * @Title: addMajorShow
	 * @Description: 显示添加专业页面
	 * @return String
	 */
	public String addMajorShow(){
		return "majorEdit";
	}
	
	/**
	 * @Title: addMajor
	 * @Description: 添加专业
	 * @return String
	 */
	public String addMajor(){
		try {
			 //添加专业
			adminManager.addMajor(paramsMajor);
			
			setSuccessTip("添加成功", "Admin_listMajors.action");
		} catch (Exception e) {
			setErrorTip("添加专业异常", "Admin_listMajors.action");
		}
		
		return "infoTip";
	}
	
	 
	/**
	 * @Title: editMajor
	 * @Description: 编辑专业
	 * @return String
	 */
	public String editMajor(){
		try {
			 //得到专业
			Major major = adminManager.queryMajor(paramsMajor);
			Param.setAttribute("major", major);
		} catch (Exception e) {
			setErrorTip("查询专业异常", "Admin_listMajors.action");
			return "infoTip";
		}
		
		return "majorEdit";
	}
	
	/**
	 * @Title: saveMajor
	 * @Description: 保存编辑专业
	 * @return String
	 */
	public String saveMajor(){
		try {
			 //保存编辑专业
			adminManager.updateMajor(paramsMajor);
			
			setSuccessTip("编辑成功", "Admin_listMajors.action");
		} catch (Exception e) {
			tip="编辑失败";
			Param.setAttribute("major", paramsMajor);
			return "majorEdit";
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: delMajors
	 * @Description: 删除专业
	 * @return String
	 */
	public String delMajors(){
		try {
			 //删除专业
			adminManager.delMajors(paramsMajor);
			
			setSuccessTip("删除专业成功", "Admin_listMajors.action");
		} catch (Exception e) {
			setErrorTip("删除专业异常", "Admin_listMajors.action");
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: listClassess
	 * @Description: 查询班级
	 * @return String
	 */
	public String listClassess(){
		try {
			if (paramsClasses==null) {
				paramsClasses = new Classes();
			}
			//设置分页信息
			setPagination(paramsClasses);
			//总的条数
			int[] sum={0};
			//查询班级列表
			List<Classes> classess = adminManager.listClassess(paramsClasses,sum); 
			
			Param.setAttribute("classess", classess);
			setTotalCount(sum[0]);
			
		} catch (Exception e) {
			setErrorTip("查询班级异常", "main.jsp");
			return "infoTip";
		}
		
		return "classesShow";
	}
	
	/**
	 * @Title: addClassesShow
	 * @Description: 显示添加班级页面
	 * @return String
	 */
	public String addClassesShow(){
		return "classesEdit";
	}
	
	/**
	 * @Title: addClasses
	 * @Description: 添加班级
	 * @return String
	 */
	public String addClasses(){
		try {
			 //添加班级
			adminManager.addClasses(paramsClasses);
			
			setSuccessTip("添加成功", "Admin_listClassess.action");
		} catch (Exception e) {
			setErrorTip("添加班级异常", "Admin_listClassess.action");
		}
		
		return "infoTip";
	}
	
	 
	/**
	 * @Title: editClasses
	 * @Description: 编辑班级
	 * @return String
	 */
	public String editClasses(){
		try {
			 //得到班级
			Classes classes = adminManager.queryClasses(paramsClasses);
			Param.setAttribute("classes", classes);
		} catch (Exception e) {
			setErrorTip("查询班级异常", "Admin_listClassess.action");
			return "infoTip";
		}
		
		return "classesEdit";
	}
	
	/**
	 * @Title: saveClasses
	 * @Description: 保存编辑班级
	 * @return String
	 */
	public String saveClasses(){
		try {
			 //保存编辑班级
			adminManager.updateClasses(paramsClasses);
			
			setSuccessTip("编辑成功", "Admin_listClassess.action");
		} catch (Exception e) {
			tip="编辑失败";
			Param.setAttribute("classes", paramsClasses);
			return "classesEdit";
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: delClassess
	 * @Description: 删除班级
	 * @return String
	 */
	public String delClassess(){
		try {
			 //删除班级
			adminManager.delClassess(paramsClasses);
			
			setSuccessTip("删除班级成功", "Admin_listClassess.action");
		} catch (Exception e) {
			setErrorTip("删除班级异常", "Admin_listClassess.action");
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: listCourses
	 * @Description: 查询课程
	 * @return String
	 */
	public String listCourses(){
		try {
			if (paramsCourse==null) {
				paramsCourse = new Course();
			}
			//设置分页信息
			setPagination(paramsCourse);
			//总的条数
			int[] sum={0};
			//查询课程列表
			List<Course> courses = adminManager.listCourses(paramsCourse,sum); 
			
			Param.setAttribute("courses", courses);
			setTotalCount(sum[0]);
			
		} catch (Exception e) {
			setErrorTip("查询课程异常", "main.jsp");
			return "infoTip";
		}
		
		return "courseShow";
	}
	
	/**
	 * @Title: addCourseShow
	 * @Description: 显示添加课程页面
	 * @return String
	 */
	public String addCourseShow(){
		return "courseEdit";
	}
	
	/**
	 * @Title: addCourse
	 * @Description: 添加课程
	 * @return String
	 */
	public String addCourse(){
		try {
			 //添加课程
			adminManager.addCourse(paramsCourse);
			
			setSuccessTip("添加成功", "Admin_listCourses.action");
		} catch (Exception e) {
			setErrorTip("添加课程异常", "Admin_listCourses.action");
		}
		
		return "infoTip";
	}
	
	 
	/**
	 * @Title: editCourse
	 * @Description: 编辑课程
	 * @return String
	 */
	public String editCourse(){
		try {
			 //得到课程
			Course course = adminManager.queryCourse(paramsCourse);
			Param.setAttribute("course", course);
		} catch (Exception e) {
			setErrorTip("查询课程异常", "Admin_listCourses.action");
			return "infoTip";
		}
		
		return "courseEdit";
	}
	
	/**
	 * @Title: saveCourse
	 * @Description: 保存编辑课程
	 * @return String
	 */
	public String saveCourse(){
		try {
			 //保存编辑课程
			adminManager.updateCourse(paramsCourse);
			
			setSuccessTip("编辑成功", "Admin_listCourses.action");
		} catch (Exception e) {
			tip="编辑失败";
			Param.setAttribute("course", paramsCourse);
			return "courseEdit";
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: delCourses
	 * @Description: 删除课程
	 * @return String
	 */
	public String delCourses(){
		try {
			 //删除课程
			adminManager.delCourses(paramsCourse);
			
			setSuccessTip("删除课程成功", "Admin_listCourses.action");
		} catch (Exception e) {
			setErrorTip("删除课程异常", "Admin_listCourses.action");
		}
		
		return "infoTip";
	}
	
	
	/**
	 * @Title: listScores
	 * @Description: 查询成绩
	 * @return String
	 */
	public String listScores(){
		try {
			if (paramsScore==null) {
				paramsScore = new Score();
			}
			//设置分页信息
			setPagination(paramsScore);
			//总的条数
			int[] sum={0};
			//用户身份限制
			User admin = (User)Param.getSession("admin");
			if (admin.getUser_type()==1) {
				paramsScore.setUser_id(admin.getUser_id());
			}
			//查询成绩列表
			List<Score> scores = adminManager.listScores(paramsScore,sum); 
			
			Param.setAttribute("scores", scores);
			setTotalCount(sum[0]);
			
			//查询班级、专业、课程字典
			Classes classes = new Classes();
			classes.setStart(-1);
			List<Classes> classess = adminManager.listClassess(classes, null);
			Param.setAttribute("classess", classess);
			
			Major major = new Major();
			major.setStart(-1);
			List<Major> majors = adminManager.listMajors(major, null);
			Param.setAttribute("majors", majors);
			
			Course course = new Course();
			course.setStart(-1);
			List<Course> courses = adminManager.listCourses(course, null);
			Param.setAttribute("courses", courses);
			
		} catch (Exception e) {
			setErrorTip("查询成绩异常", "main.jsp");
			return "infoTip";
		}
		
		return "scoreShow";
	}
	
	/**
	 * @Title: addScoreShow
	 * @Description: 显示添加成绩页面
	 * @return String
	 */
	public String addScoreShow(){
		//查询班级、专业、课程字典
		Classes classes = new Classes();
		classes.setStart(-1);
		List<Classes> classess = adminManager.listClassess(classes, null);
		Param.setAttribute("classess", classess);
		
		Major major = new Major();
		major.setStart(-1);
		List<Major> majors = adminManager.listMajors(major, null);
		Param.setAttribute("majors", majors);
		
		Course course = new Course();
		course.setStart(-1);
		List<Course> courses = adminManager.listCourses(course, null);
		Param.setAttribute("courses", courses);
		
		return "scoreEdit";
	}
	
	/**
	 * @Title: addScore
	 * @Description: 添加成绩
	 * @return String
	 */
	public String addScore(){
		try {
			//判断成绩是否已经添加
			Score score = adminManager.queryScore(paramsScore);
			if (score!=null) {
				tip = "失败，该学生本次成绩已经存在！";
				Param.setAttribute("score", paramsScore);
				
				//查询班级、专业、课程字典
				Classes classes = new Classes();
				classes.setStart(-1);
				List<Classes> classess = adminManager.listClassess(classes, null);
				Param.setAttribute("classess", classess);
				
				Major major = new Major();
				major.setStart(-1);
				List<Major> majors = adminManager.listMajors(major, null);
				Param.setAttribute("majors", majors);
				
				Course course = new Course();
				course.setStart(-1);
				List<Course> courses = adminManager.listCourses(course, null);
				Param.setAttribute("courses", courses);
				
				return "scoreEdit";
			}
			
			//添加成绩
			adminManager.addScore(paramsScore);
			
			setSuccessTip("添加成功", "Admin_listScores.action");
		} catch (Exception e) {
			setErrorTip("添加成绩异常", "Admin_listScores.action");
			e.printStackTrace();
		}
		
		return "infoTip";
	}
	
	 
	/**
	 * @Title: editScore
	 * @Description: 编辑成绩
	 * @return String
	 */
	public String editScore(){
		try {
			 //得到成绩
			Score score = adminManager.queryScore(paramsScore);
			Param.setAttribute("score", score);
			
			//查询课程字典
			Course course = new Course();
			course.setStart(-1);
			List<Course> courses = adminManager.listCourses(course, null);
			Param.setAttribute("courses", courses);
			
		} catch (Exception e) {
			setErrorTip("查询成绩异常", "Admin_listScores.action");
			return "infoTip";
		}
		
		return "scoreEdit";
	}
	
	/**
	 * @Title: saveScore
	 * @Description: 保存编辑成绩
	 * @return String
	 */
	public String saveScore(){
		try {
			 //保存编辑成绩
			adminManager.updateScore(paramsScore);
			
			setSuccessTip("编辑成功", "Admin_listScores.action");
		} catch (Exception e) {
			tip="编辑失败";
			Param.setAttribute("score", paramsScore);
			
			//查询课程字典
			Course course = new Course();
			course.setStart(-1);
			List<Course> courses = adminManager.listCourses(course, null);
			Param.setAttribute("courses", courses);
			
			return "scoreEdit";
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: delScores
	 * @Description: 删除成绩
	 * @return String
	 */
	public String delScores(){
		try {
			 //删除成绩
			adminManager.delScores(paramsScore);
			
			setSuccessTip("删除成绩成功", "Admin_listScores.action");
		} catch (Exception e) {
			setErrorTip("删除成绩异常", "Admin_listScores.action");
		}
		
		return "infoTip";
	}
	
	/**
	 * @Title: validateAdmin
	 * @Description: admin登录验证
	 * @return boolean
	 */
	private boolean validateAdmin(){
		User admin = (User)Param.getSession("admin");
		if (admin!=null) {
			return true;
		}else {
			return false;
		}
	}
	
	private void setErrorTip(String tip,String url){
		Param.setAttribute("tipType", "error");
		Param.setAttribute("tip", tip);
		Param.setAttribute("url1", url);
		Param.setAttribute("value1", "确 定");
	}
	
	private void setSuccessTip(String tip,String url){
		Param.setAttribute("tipType", "success");
		Param.setAttribute("tip", tip);
		Param.setAttribute("url1", url);
		Param.setAttribute("value1", "确 定");
	}

	public User getParamsUser() {
		return paramsUser;
	}

	public void setParamsUser(User paramsUser) {
		this.paramsUser = paramsUser;
	}

	public Classes getParamsClasses() {
		return paramsClasses;
	}

	public void setParamsClasses(Classes paramsClasses) {
		this.paramsClasses = paramsClasses;
	}

	public Course getParamsCourse() {
		return paramsCourse;
	}

	public void setParamsCourse(Course paramsCourse) {
		this.paramsCourse = paramsCourse;
	}

	public Major getParamsMajor() {
		return paramsMajor;
	}

	public void setParamsMajor(Major paramsMajor) {
		this.paramsMajor = paramsMajor;
	}

	public Score getParamsScore() {
		return paramsScore;
	}

	public void setParamsScore(Score paramsScore) {
		this.paramsScore = paramsScore;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}
	
	 
	
}
