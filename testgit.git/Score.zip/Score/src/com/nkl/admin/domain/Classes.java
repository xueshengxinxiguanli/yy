package com.nkl.admin.domain;

import com.nkl.common.domain.BaseDomain;

public class Classes extends BaseDomain {
	/**
	 * @Fields serialVersionUID : TODO
	 */
	private static final long serialVersionUID = -6857687703848840086L;
	private int classes_id; // 
	private String classes_name; // 
	private String depart_name; // 
	private String note; // 

	private String ids;
	private String random;

	public void setClasses_id(int classes_id){
		this.classes_id=classes_id;
	}

	public int getClasses_id(){
		return classes_id;
	}

	public void setClasses_name(String classes_name){
		this.classes_name=classes_name;
	}

	public String getClasses_name(){
		return classes_name;
	}

	public void setDepart_name(String depart_name){
		this.depart_name=depart_name;
	}

	public String getDepart_name(){
		return depart_name;
	}

	public void setNote(String note){
		this.note=note;
	}

	public String getNote(){
		return note;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public String getIds() {
		return ids;
	}

	public void setRandom(String random) {
		this.random = random;
	}

	public String getRandom() {
		return random;
	}

}
