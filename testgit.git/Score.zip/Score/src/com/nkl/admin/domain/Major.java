package com.nkl.admin.domain;

import com.nkl.common.domain.BaseDomain;

public class Major extends BaseDomain {
	/**
	 * @Fields serialVersionUID : TODO
	 */
	private static final long serialVersionUID = 2408088462183730648L;
	private int major_id; // 
	private String major_name; // 
	private String note; // 

	private String ids;
	private String random;

	public void setMajor_id(int major_id){
		this.major_id=major_id;
	}

	public int getMajor_id(){
		return major_id;
	}

	public void setMajor_name(String major_name){
		this.major_name=major_name;
	}

	public String getMajor_name(){
		return major_name;
	}

	public void setNote(String note){
		this.note=note;
	}

	public String getNote(){
		return note;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public String getIds() {
		return ids;
	}

	public void setRandom(String random) {
		this.random = random;
	}

	public String getRandom() {
		return random;
	}

}
