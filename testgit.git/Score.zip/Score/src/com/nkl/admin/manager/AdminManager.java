package com.nkl.admin.manager;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import com.nkl.admin.dao.ClassesDao;
import com.nkl.admin.dao.CourseDao;
import com.nkl.admin.dao.MajorDao;
import com.nkl.admin.dao.ScoreDao;
import com.nkl.admin.dao.UserDao;
import com.nkl.admin.domain.Classes;
import com.nkl.admin.domain.Course;
import com.nkl.admin.domain.Major;
import com.nkl.admin.domain.Score;
import com.nkl.admin.domain.User;
import com.nkl.common.dao.BaseDao;
import com.nkl.common.util.Md5;
import com.nkl.common.util.StringUtil;

public class AdminManager {

	ClassesDao classesDao = new ClassesDao();
	CourseDao courseDao = new CourseDao();
	MajorDao majorDao = new MajorDao();
	ScoreDao scoreDao = new ScoreDao();
	UserDao userDao = new UserDao();

	/**
	 * @Title: listUsers
	 * @Description: 用户查询
	 * @param user
	 * @return List<User>
	 */
	public List<User> listUsers(User user, int[] sum) {
		Connection conn = BaseDao.getConnection();
		if (sum != null) {
			sum[0] = userDao.listUsersCount(user, conn);
		}
		List<User> users = userDao.listUsers(user, conn);

		BaseDao.closeDB(null, null, conn);
		return users;
	}

	/**
	 * @Title: editUser
	 * @Description: 编辑用户信息
	 * @param user
	 * @return void
	 */
	public void editUser(User user) {
		Connection conn = BaseDao.getConnection();

		userDao.updateUser(user, conn);

		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: queryUser
	 * @Description: 用户查询
	 * @param user
	 * @return User
	 */
	public User queryUser(User user) {
		Connection conn = BaseDao.getConnection();
		User _user = userDao.getUser(user, conn);
		BaseDao.closeDB(null, null, conn);
		return _user;
	}

	/**
	 * @Title: addUser
	 * @Description: 添加用户
	 * @param user
	 * @return void
	 */
	public void addUser(User user) {
		Connection conn = BaseDao.getConnection();
		if (!StringUtil.isEmptyString(user.getUser_pass())) {
			user.setUser_pass(Md5.makeMd5(user.getUser_pass()));
		}
		userDao.addUser(user, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: updateUser
	 * @Description: 更新用户信息
	 * @param user
	 * @return void
	 */
	public void updateUser(User user) {
		Connection conn = BaseDao.getConnection();
		if (!StringUtil.isEmptyString(user.getUser_pass())) {
			user.setUser_pass(Md5.makeMd5(user.getUser_pass()));
		}
		userDao.updateUser(user, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: delUsers
	 * @Description: 删除用户信息
	 * @param user
	 * @return void
	 */
	public void delUsers(User user) {
		Connection conn = BaseDao.getConnection();
		userDao.delUsers(user.getIds().split(","), conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: listClassess
	 * @Description: 班级查询
	 * @param classes
	 * @return List<Classes>
	 */
	public List<Classes> listClassess(Classes classes, int[] sum) {
		Connection conn = BaseDao.getConnection();
		if (sum != null) {
			sum[0] = classesDao.listClassessCount(classes, conn);
		}
		List<Classes> classess = classesDao.listClassess(classes, conn);

		BaseDao.closeDB(null, null, conn);
		return classess;
	}

	/**
	 * @Title: editClasses
	 * @Description: 编辑班级信息
	 * @param classes
	 * @return void
	 */
	public void editClasses(Classes classes) {
		Connection conn = BaseDao.getConnection();

		classesDao.updateClasses(classes, conn);

		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: queryClasses
	 * @Description: 班级查询
	 * @param classes
	 * @return Classes
	 */
	public Classes queryClasses(Classes classes) {
		Connection conn = BaseDao.getConnection();
		Classes _classes = classesDao.getClasses(classes, conn);
		BaseDao.closeDB(null, null, conn);
		return _classes;
	}

	/**
	 * @Title: addClasses
	 * @Description: 添加班级
	 * @param classes
	 * @return void
	 */
	public void addClasses(Classes classes) {
		Connection conn = BaseDao.getConnection();
		classesDao.addClasses(classes, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: updateClasses
	 * @Description: 更新班级信息
	 * @param classes
	 * @return void
	 */
	public void updateClasses(Classes classes) {
		Connection conn = BaseDao.getConnection();
		classesDao.updateClasses(classes, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: delClassess
	 * @Description: 删除班级信息
	 * @param classes
	 * @return void
	 */
	public void delClassess(Classes classes) {
		Connection conn = BaseDao.getConnection();
		classesDao.delClassess(classes.getIds().split(","), conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: listMajors
	 * @Description: 专业查询
	 * @param major
	 * @return List<Major>
	 */
	public List<Major> listMajors(Major major, int[] sum) {
		Connection conn = BaseDao.getConnection();
		if (sum != null) {
			sum[0] = majorDao.listMajorsCount(major, conn);
		}
		List<Major> majors = majorDao.listMajors(major, conn);

		BaseDao.closeDB(null, null, conn);
		return majors;
	}

	/**
	 * @Title: editMajor
	 * @Description: 编辑专业信息
	 * @param major
	 * @return void
	 */
	public void editMajor(Major major) {
		Connection conn = BaseDao.getConnection();

		majorDao.updateMajor(major, conn);

		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: queryMajor
	 * @Description: 专业查询
	 * @param major
	 * @return Major
	 */
	public Major queryMajor(Major major) {
		Connection conn = BaseDao.getConnection();
		Major _major = majorDao.getMajor(major, conn);
		BaseDao.closeDB(null, null, conn);
		return _major;
	}

	/**
	 * @Title: addMajor
	 * @Description: 添加专业
	 * @param major
	 * @return void
	 */
	public void addMajor(Major major) {
		Connection conn = BaseDao.getConnection();
		majorDao.addMajor(major, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: updateMajor
	 * @Description: 更新专业信息
	 * @param major
	 * @return void
	 */
	public void updateMajor(Major major) {
		Connection conn = BaseDao.getConnection();
		majorDao.updateMajor(major, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: delMajors
	 * @Description: 删除专业信息
	 * @param major
	 * @return void
	 */
	public void delMajors(Major major) {
		Connection conn = BaseDao.getConnection();
		majorDao.delMajors(major.getIds().split(","), conn);
		BaseDao.closeDB(null, null, conn);
	}
	
	/**
	 * @Title: listCourses
	 * @Description: 课程查询
	 * @param course
	 * @return List<Course>
	 */
	public List<Course> listCourses(Course course, int[] sum) {
		Connection conn = BaseDao.getConnection();
		if (sum != null) {
			sum[0] = courseDao.listCoursesCount(course, conn);
		}
		List<Course> courses = courseDao.listCourses(course, conn);

		BaseDao.closeDB(null, null, conn);
		return courses;
	}

	/**
	 * @Title: editCourse
	 * @Description: 编辑课程信息
	 * @param course
	 * @return void
	 */
	public void editCourse(Course course) {
		Connection conn = BaseDao.getConnection();

		courseDao.updateCourse(course, conn);

		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: queryCourse
	 * @Description: 课程查询
	 * @param course
	 * @return Course
	 */
	public Course queryCourse(Course course) {
		Connection conn = BaseDao.getConnection();
		Course _course = courseDao.getCourse(course, conn);
		BaseDao.closeDB(null, null, conn);
		return _course;
	}

	/**
	 * @Title: addCourse
	 * @Description: 添加课程
	 * @param course
	 * @return void
	 */
	public void addCourse(Course course) {
		Connection conn = BaseDao.getConnection();
		courseDao.addCourse(course, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: updateCourse
	 * @Description: 更新课程信息
	 * @param course
	 * @return void
	 */
	public void updateCourse(Course course) {
		Connection conn = BaseDao.getConnection();
		courseDao.updateCourse(course, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: delCourses
	 * @Description: 删除课程信息
	 * @param course
	 * @return void
	 */
	public void delCourses(Course course) {
		Connection conn = BaseDao.getConnection();
		courseDao.delCourses(course.getIds().split(","), conn);
		BaseDao.closeDB(null, null, conn);
	}
	
	/**
	 * @Title: listScores
	 * @Description: 成绩查询
	 * @param score
	 * @return List<Score>
	 */
	public List<Score> listScores(Score score, int[] sum) {
		Connection conn = BaseDao.getConnection();
		if (sum != null) {
			sum[0] = scoreDao.listScoresCount(score, conn);
		}
		List<Score> scores = scoreDao.listScores(score, conn);

		BaseDao.closeDB(null, null, conn);
		return scores;
	}
	

	/**
	 * @Title: editScore
	 * @Description: 编辑成绩信息
	 * @param score
	 * @return void
	 */
	public void editScore(Score score) {
		Connection conn = BaseDao.getConnection();

		scoreDao.updateScore(score, conn);

		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: queryScore
	 * @Description: 成绩查询
	 * @param score
	 * @return Score
	 */
	public Score queryScore(Score score) {
		Connection conn = BaseDao.getConnection();
		Score _score = scoreDao.getScore(score, conn);
		BaseDao.closeDB(null, null, conn);
		return _score;
	}

	/**
	 * @Title: addScore
	 * @Description: 添加成绩
	 * @param score
	 * @return void
	 */
	public void addScore(Score score) {
		Connection conn = BaseDao.getConnection();
		scoreDao.addScore(score, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: updateScore
	 * @Description: 更新成绩信息
	 * @param score
	 * @return void
	 */
	public void updateScore(Score score) {
		Connection conn = BaseDao.getConnection();
		scoreDao.updateScore(score, conn);
		BaseDao.closeDB(null, null, conn);
	}

	/**
	 * @Title: delScores
	 * @Description: 删除成绩信息
	 * @param score
	 * @return void
	 */
	public void delScores(Score score) {
		Connection conn = BaseDao.getConnection();
		scoreDao.delScores(score.getIds().split(","), conn);
		BaseDao.closeDB(null, null, conn);
	}
	
	/**
	 * @Title: listSingleScoresStudent
	 * @Description: 查询学生各科成绩
	 * @param score
	 * @return List<Score>
	 */
	public List<Score> listSingleScoresStudent(Score score) {
		Connection conn = BaseDao.getConnection();
		List<Score> scores = scoreDao.listScores(score, conn);
		if (scores!=null && scores.size()>0) {
			//查询各科成绩排名
			for (Score temp : scores) {
				score.setCourse_id(temp.getCourse_id());
				Map<Integer,Score> map = scoreDao.listSingleScoresIndex(score, conn);
				temp.setScore_index(map.get(Integer.valueOf(score.getUser_id())).getScore_index());
			}
		}
		
		BaseDao.closeDB(null, null, conn);
		return scores;
	}
	
	/**
	 * @Title: listSingleScores
	 * @Description: 单科成绩排名
	 * @param score
	 * @return List<Score>
	 */
	public List<Score> listSingleScores(Score score,int[] sum) {
		Connection conn = BaseDao.getConnection();
		if (sum!=null) {
			sum[0] = scoreDao.listScoresCount(score, conn);
		}
		List<Score> scores = scoreDao.listScores(score, conn);
		if (scores!=null && scores.size()>0) {
			//查询单科成绩排名索引
			Map<Integer,Score> map = scoreDao.listSingleScoresIndex(score, conn);
			//查询单科成绩排名
			for (Score score2 : scores) {
				score2.setScore_index(map.get(score2.getUser_id()).getScore_index());
			}
		}
		
		BaseDao.closeDB(null, null, conn);
		return scores;
	}
	
	/**
	 * @Title: listSumScores
	 * @Description: 总分成绩
	 * @param score
	 * @return List<Score>
	 */
	public List<Score> listSumScores(Score score,int[] sum) {
		Connection conn = BaseDao.getConnection();
		if (sum!=null) {
			sum[0] = scoreDao.listSumScoresCount(score, conn);
		}
		List<Score> scores = scoreDao.listSumScores(score, conn);
		
		if (scores!=null && scores.size()>0) {
			//查询总分成绩排名索引
			Map<Integer,Score> map = scoreDao.listSumScoresIndex(score, conn);
			//查询总分成绩排名
			for (Score score2 : scores) {
				score2.setScore_index(map.get(score2.getUser_id()).getScore_index());
			}
		}

		BaseDao.closeDB(null, null, conn);
		return scores;
	}
	
	/**
	 * @Title: listSingleScoresIndex
	 * @Description: 单科成绩排名索引
	 * @param score
	 * @return Map<Integer,Score>
	 */
	public Map<Integer,Score> listSingleScoresIndex(Score score) {
		Connection conn = BaseDao.getConnection();
		Map<Integer,Score> maps = scoreDao.listSingleScoresIndex(score, conn);

		BaseDao.closeDB(null, null, conn);
		return maps;
	}
	
	/**
	 * @Title: listSumScoresIndex
	 * @Description: 总分成绩排名索引
	 * @param score
	 * @return Map<Integer,Score>
	 */
	public Map<Integer,Score> listSumScoresIndex(Score score) {
		Connection conn = BaseDao.getConnection();
		Map<Integer,Score> maps = scoreDao.listSumScoresIndex(score, conn);

		BaseDao.closeDB(null, null, conn);
		return maps;
	}
	
	/**
	 * @Title: listSingleAvgScores
	 * @Description: 查询单科平均分
	 * @param score
	 * @return Map<Integer,Score>
	 */
	public double listSingleAvgScores(Score score) {
		Connection conn = BaseDao.getConnection();
		double avg = scoreDao.listSingleAvgScores(score, conn);

		BaseDao.closeDB(null, null, conn);
		return avg;
	}
	
	/**
	 * @Title: listSumAvgScores
	 * @Description: 查询所有科目平均分
	 * @param score
	 * @return Map<Integer,Score>
	 */
	public double listSumAvgScores(Score score) {
		Connection conn = BaseDao.getConnection();
		double avg = scoreDao.listSumAvgScores(score, conn);

		BaseDao.closeDB(null, null, conn);
		return avg;
	}
	
	/**
	 * @Title: listSingleScoresSection
	 * @Description: 查询单科成绩分布
	 * @param score
	 * @return List<Score>
	 */
	public List<Score> listSingleScoresSection(Score score) {
		Connection conn = BaseDao.getConnection();
		List<Score> scores = scoreDao.listSingleScoresSection(score, conn);

		BaseDao.closeDB(null, null, conn);
		return scores;
	}
	
	/**
	 * @Title: listSumScoresSection
	 * @Description: 查询总分成绩分布
	 * @param score
	 * @return List<Score>
	 */
	public List<Score> listSumScoresSection(Score score) {
		Connection conn = BaseDao.getConnection();
		List<Score> scores = scoreDao.listSumScoresSection(score, conn);

		BaseDao.closeDB(null, null, conn);
		return scores;
	}
}
