package com.nkl.admin.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.nkl.admin.domain.Classes;
import com.nkl.common.dao.BaseDao;
import com.nkl.common.util.StringUtil;

public class ClassesDao {

	public int addClasses(Classes classes, Connection conn){
		String sql = "INSERT INTO classes(classes_id,classes_name,depart_name,note) values(null,?,?,?)";
		Object[] params = new Object[] {
			classes.getClasses_name(),
			classes.getDepart_name(),
			classes.getNote()

		};
		return BaseDao.executeUpdate(sql, params, conn );
	}

	public int delClasses(String classes_id, Connection conn){
		String sql = "DELETE FROM score WHERE classes_id=?";

		Object[] params = new Object[] { new Integer(classes_id)};
		return BaseDao.executeUpdate(sql, params, conn);
	}

	public int delClassess(String[] classes_ids, Connection conn){
		StringBuilder sBuilder = new StringBuilder();
		for (int i = 0; i <classes_ids.length; i++) {
			sBuilder.append("?");
			if (i !=classes_ids.length-1) {
				sBuilder.append(",");
			}
		}
		String sql = "DELETE FROM classes WHERE classes_id IN(" +sBuilder.toString()+")";

		Object[] params = classes_ids;

		return BaseDao.executeUpdate(sql, params, conn);
	}

	public int updateClasses(Classes classes, Connection conn){
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("UPDATE classes SET classes_id = " + classes.getClasses_id() +" ");
		if (!StringUtil.isEmptyString(classes.getClasses_name())) {
			sBuilder.append(" ,classes_name = '" + classes.getClasses_name() +"' ");
		}
		if (!StringUtil.isEmptyString(classes.getNote())) {
			sBuilder.append(" ,note = '" + classes.getNote() +"' ");
		}
		sBuilder.append(" where classes_id = " + classes.getClasses_id() +" ");

		Object[] params = null;
		return BaseDao.executeUpdate(sBuilder.toString(), params, conn);
	}

	public Classes getClasses(Classes classes, Connection conn){
		Classes _classes=null;
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("SELECT * FROM classes WHERE 1=1");
		if (classes.getClasses_id()!=0) {
			sBuilder.append(" and classes_id = " + classes.getClasses_id() +" ");
		}

		List<Object> list = BaseDao.executeQuery(Classes.class.getName(), sBuilder.toString(), null, conn);
		if (list != null && list.size() > 0) {
			 _classes = (Classes)list.get(0);
		}
		return _classes;
	}

	public List<Classes>  listClassess(Classes classes, Connection conn){
		List<Classes> classess = null;
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("SELECT * FROM (");
		sBuilder.append("SELECT * FROM classes WHERE 1=1");

		if (classes.getClasses_id()!=0) {
			sBuilder.append(" and classes_id = " + classes.getClasses_id() +" ");
		}
		if (!StringUtil.isEmptyString(classes.getClasses_name())) {
			sBuilder.append(" and classes_name like '%" + classes.getClasses_name() +"%' ");
		}
		sBuilder.append(" order by classes_id asc) t");

		if (classes.getStart() != -1) {
			sBuilder.append(" limit " + classes.getStart() + "," + classes.getLimit());
		}

		List<Object> list = BaseDao.executeQuery(Classes.class.getName(), sBuilder.toString(), null, conn);
		if (list != null && list.size() > 0) {
			classess = new ArrayList<Classes>();
			for (Object object : list) {
				classess.add((Classes)object);
			}
		}
		return classess;
	}

	public int  listClassessCount(Classes classes, Connection conn){
		int sum = 0;
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("SELECT count(*) FROM classes WHERE 1=1");

		if (classes.getClasses_id()!=0) {
			sBuilder.append(" and classes_id = " + classes.getClasses_id() +" ");
		}
		if (!StringUtil.isEmptyString(classes.getClasses_name())) {
			sBuilder.append(" and classes_name like '%" + classes.getClasses_name() +"%' ");
		}

		long count = (Long)BaseDao.executeQueryObject(sBuilder.toString(), null, conn);
		sum = (int)count;
		return sum;
	}

}
