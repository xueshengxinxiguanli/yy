package com.nkl.admin.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.nkl.admin.domain.Major;
import com.nkl.common.dao.BaseDao;
import com.nkl.common.util.StringUtil;

public class MajorDao {

	public int addMajor(Major major, Connection conn){
		String sql = "INSERT INTO major(major_id,major_name,note) values(null,?,?)";
		Object[] params = new Object[] {
			major.getMajor_name(),
			major.getNote()

		};
		return BaseDao.executeUpdate(sql, params, conn );
	}

	public int delMajor(String major_id, Connection conn){
		String sql = "DELETE FROM score WHERE major_id=?";

		Object[] params = new Object[] { new Integer(major_id)};
		return BaseDao.executeUpdate(sql, params, conn);
	}

	public int delMajors(String[] major_ids, Connection conn){
		StringBuilder sBuilder = new StringBuilder();
		for (int i = 0; i <major_ids.length; i++) {
			sBuilder.append("?");
			if (i !=major_ids.length-1) {
				sBuilder.append(",");
			}
		}
		String sql = "DELETE FROM major WHERE major_id IN(" +sBuilder.toString()+")";

		Object[] params = major_ids;

		return BaseDao.executeUpdate(sql, params, conn);
	}

	public int updateMajor(Major major, Connection conn){
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("UPDATE major SET major_id = " + major.getMajor_id() +" ");
		if (!StringUtil.isEmptyString(major.getMajor_name())) {
			sBuilder.append(" ,major_name = '" + major.getMajor_name() +"' ");
		}
		if (!StringUtil.isEmptyString(major.getNote())) {
			sBuilder.append(" ,note = '" + major.getNote() +"' ");
		}
		sBuilder.append(" where major_id = " + major.getMajor_id() +" ");

		Object[] params = null;
		return BaseDao.executeUpdate(sBuilder.toString(), params, conn);
	}

	public Major getMajor(Major major, Connection conn){
		Major _major=null;
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("SELECT * FROM major WHERE 1=1");
		if (major.getMajor_id()!=0) {
			sBuilder.append(" and major_id = " + major.getMajor_id() +" ");
		}

		List<Object> list = BaseDao.executeQuery(Major.class.getName(), sBuilder.toString(), null, conn);
		if (list != null && list.size() > 0) {
			 _major = (Major)list.get(0);
		}
		return _major;
	}

	public List<Major>  listMajors(Major major, Connection conn){
		List<Major> majors = null;
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("SELECT * FROM (");
		sBuilder.append("SELECT * FROM major WHERE 1=1");

		if (major.getMajor_id()!=0) {
			sBuilder.append(" and major_id = " + major.getMajor_id() +" ");
		}
		if (!StringUtil.isEmptyString(major.getMajor_name())) {
			sBuilder.append(" and major_name like '%" + major.getMajor_name() +"%' ");
		}
		sBuilder.append(" order by major_id asc) t");

		if (major.getStart() != -1) {
			sBuilder.append(" limit " + major.getStart() + "," + major.getLimit());
		}

		List<Object> list = BaseDao.executeQuery(Major.class.getName(), sBuilder.toString(), null, conn);
		if (list != null && list.size() > 0) {
			majors = new ArrayList<Major>();
			for (Object object : list) {
				majors.add((Major)object);
			}
		}
		return majors;
	}

	public int  listMajorsCount(Major major, Connection conn){
		int sum = 0;
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("SELECT count(*) FROM major WHERE 1=1");

		if (major.getMajor_id()!=0) {
			sBuilder.append(" and major_id = " + major.getMajor_id() +" ");
		}
		if (!StringUtil.isEmptyString(major.getMajor_name())) {
			sBuilder.append(" and major_name like '%" + major.getMajor_name() +"%' ");
		}

		long count = (Long)BaseDao.executeQueryObject(sBuilder.toString(), null, conn);
		sum = (int)count;
		return sum;
	}

}
